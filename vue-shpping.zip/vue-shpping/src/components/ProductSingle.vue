<template>
  <div v-if="loading">Loading...</div>
    <div v-else>
    <el-row >
      <el-col :span="12">
        <!-- Render each product using Element UI Card component -->
        <el-card :body-style="{ padding: '0' }">
          <img :src="product.thumbnail" class="product-image" alt="product image" width="100%">
          </el-card>
          </el-col> 
        <el-col :span="6">
          <div style="padding: 14px;">
            <h2>{{ product.title }}</h2>
            <h5>{{ product.category }}</h5>
            <p>{{ product.stock }}</p>
            <p>{{ product.description }} echnology is the application of conceptual knowledge for achieving practical goals, </p><el-rate v-model="rating" :max="5"></el-rate>
           
            <div class="bottom clearfix">
              <span class="price" style="color: red;font-size: 40px;">${{ product.price }}</span>
              <el-button type="primary" style="float: right;margin: 20px;">Add to Cart</el-button>
            </div>
            <div class="products" v-for="product in items" :key="product.id">   
        {{ product.title }}
        <button @click="addToCart(product.id)">Add to Cart</button>
     </div>
          </div>
          </el-col>    
    </el-row>
    <el-row>
      <el-col :span="12">
        <div>
    <el-carousel :interval="5000" arrow="always" indicator-position="outside">
      <el-carousel-item v-for="(image, index) in product.images" :key="index">
        <img :src="image" alt="Product Image" style="width: 100%;" />
      </el-carousel-item>
    </el-carousel>
  </div>
  </el-col>
    </el-row>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue';
import axios from 'axios';
import { useRoute} from 'vue-router'
export default {
  setup() {
    const product = ref(null);
    const loading = ref(true);
    const route = useRoute();
    onMounted(async () => {
      try {
        let id = route.params.id;
        console.log('id', id)
        const response = await axios.get('https://dummyjson.com/products/' + id);
        product.value = response.data;
        loading.value = false;
      } catch (error) {
        console.error('Error fetching products:', error);
        loading.value = false;
      }
    });
    
    
    
    return { 
      product, 
      loading,
      cart: [],
    
    };
    
  }
};
</script>
