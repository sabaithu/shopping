<template>
    <el-button type="danger" @click="logout">Logout</el-button>
  </template>
  
  <script>
  export default {
    methods: {
      logout() {
        // Call authentication service to logout
        // Redirect to login page
      }
    }
  }
  </script>
  