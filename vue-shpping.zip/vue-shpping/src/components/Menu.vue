<script setup>

const handleSelect = function() {

}
const activeIndex2 = true



</script>
<template>
  <div class="common-layout" style="margin-bottom:40px">
    <el-menu
        :default-active="activeIndex2"
        class="el-menu-demo"
        mode="horizontal"
        background-color="#FF9800"
        text-color="#5a5757"
        active-text-color="#ffd04b"
        font-size="18px"
        @select="handleSelect"
      >
      <el-menu-item index="1"><router-link to="/"><img src="https://upload.wikimedia.org/wikipedia/commons/3/3f/Yello_logo_yellow_rgb.png" width="50px"></router-link></el-menu-item>
       
        <el-sub-menu index="2">
          <template #title><a href="@product">Product Category</a></template>
          <el-menu-item index="2-1">Smart Phone</el-menu-item>
          <el-menu-item index="2-2">Laptop</el-menu-item>
          <el-menu-item index="2-3">Care </el-menu-item>
          
        </el-sub-menu>
      
        <el-menu-item index="4"><router-link to="/order">Order</router-link></el-menu-item>
        <el-menu-item index="5"><router-link to="/product-list">Product</router-link></el-menu-item>
        <el-menu-item index="6"><router-link to="/login">Login</router-link></el-menu-item>
        <el-menu-item index="6"><router-link to="/singup">Sing up</router-link></el-menu-item>
        <el-menu-item index="7">Logout <font-awesome-icon icon="star-half-stroke" /><i class="fas fa-cloud"></i></el-menu-item>
        <el-menu-item index="3"><router-link to="/card"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 1024 1024"><path fill="currentColor" d="M432 928a48 48 0 1 1 0-96a48 48 0 0 1 0 96m320 0a48 48 0 1 1 0-96a48 48 0 0 1 0 96M96 128a32 32 0 0 1 0-64h160a32 32 0 0 1 31.36 25.728L320.64 256H928a32 32 0 0 1 31.296 38.72l-96 448A32 32 0 0 1 832 768H384a32 32 0 0 1-31.36-25.728L229.76 128zm314.24 576h395.904l82.304-384H333.44z"/></svg>
          <el-badge :value="9" class="item"></el-badge></router-link>
          </el-menu-item>
       
          
      </el-menu>
    </div>
  <!-- <component :is="currentView" /> -->
</template>  
<style scoped>
h1 {
  font-weight: 500;
  font-size: 2.6rem;
  position: relative;
  top: -10px;
}

h3 {
  font-size: 1.2rem;
}

.greetings h1,
.greetings h3 {
  text-align: center;
}

@media (min-width: 1024px) {
  .greetings h1,
  .greetings h3 {
    text-align: left;
  }
}
</style>
