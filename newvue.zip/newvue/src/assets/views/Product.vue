<template>
    <div class="product"></div>
</template>
<script>


export default{
    name : Product
}
</script>
