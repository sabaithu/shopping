

<template>
  <button @click="getPosts">Show Posts</button>
  <hr>
  
  <div>
    <div>
    <h2>Product List</h2>
    
  </div>
    <el-col :span="8"  v-for="p in post" :key="p.id">
    <a href="#">
      <img src="https://firebasestorage.googleapis.com/v0/b/tech-geeks-platform.appspot.com/o/images%2F5.png?alt=media&amp;token=bae0f293-650e-4b8c-b850-9e78b23198d5">
    </a>
      <a href="#"><h5 class="card-title">{{ p.userId }} - {{  p.title }} </h5></a><span  style="color: red;">$999</span>
      <p>{{ p.body }} <span class="float-end"><a href="#" class="small text-muted text-uppercase aff-link">More.. </a></span></p>
        
      <button data-bs-toggle="modal" data-bs-target="#exampleModal" class="btn btn-primary"> add to cart </button>
      <span :span="3"><el-rate
    v-model="value2"
    :colors="colors">
  </el-rate></span>
</el-col>
    </div>
   
    
    <hr>
 
  <div class="common-layout">
    
    <el-row :gutter="20">
      <el-col :offset="8">
            <div class="grid-content bg-purple-light"><el-pagination
          background
          layout="prev, pager, next"
          :total="1000">
          </el-pagination></div>
        </el-col>
      </el-row>
    </div>
</template>

<script>

export default{
  data(){
      return {
        post :[],
        postData: {id:'', title:'',body:''}
      }
   
  },
  methods: {
    getPosts(){
      fetch('https://jsonplaceholder.typicode.com/posts')
      .then(response => response.json())
      .then(data => this.post = data )
    },
    setPost(){
      fetch('https://jsonplaceholder.typicode.com/posts',{
        method:'POST',
        headers: {
          'Content-Type':'application/json'
        },
        body: JSON.stringify({
          userId :this.userId,
          title  :this.title,
          body   :this.body,
        })
      })
      .then(response => response.json())
      .then(data=> console.log(data))
     
    },
    updatePost(){
      fetch('https://jsonplaceholder.typicode.com/posts/1',{
        method:'PUT',
        headers: {
          'Content-Type':'application/json'
        },
        body: JSON.stringify({
          userId :1,
          id:1,
          title  :'New Title',
          body   :'New body text',
        })
      })
      .then(response => response.json())
      .then(data=> console.log(data))

    }
  }
}

</script>
<style scoped>
header {
  line-height: 1.5;
}

.logo {
  display: block;
  margin: 0 auto 2rem;
}

@media (min-width: 1024px) {
  header {
    display: flex;
    place-items: center;
    padding-right: calc(var(--section-gap) / 2);
  }

  .logo {
    margin: 0 2rem 0 0;
  }

  header .wrapper {
    display: flex;
    place-items: flex-start;
    flex-wrap: wrap;
  }
}

.pagination-container {
    display: flex;
    column-gap: 10px;
  }
  .paginate-buttons {
    height: 40px;
    width: 40px;
    border-radius: 20px;
    cursor: pointer;
    background-color: rgb(242, 242, 242);
    border: 1px solid rgb(217, 217, 217);
    color: black;
  }
  .paginate-buttons:hover {
    background-color: #d8d8d8;
  }
  .active-page {
    background-color: #3498db;
    border: 1px solid #3498db;
    color: white;
  }
  .active-page:hover {
    background-color: #2988c8;
  }
</style>

