<template>
  <div>
    <h2>Product Order List</h2>
    <el-table :data="products" style="width: 100%">
      <el-table-column prop="title" label="Product Name"></el-table-column>
      <el-table-column prop="price" label="Price"></el-table-column>
      <el-table-column prop="quantity" label="Quantity"> </el-table-column>
      <el-table-column prop="total" label="Total Price"></el-table-column>
    </el-table>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue';
import { ElTable, ElTableColumn } from 'element-plus';

export default {
  components: {
    ElTable,
    ElTableColumn
  },
  setup() {
    const products = ref([]);
    
    const limit = 10; // Set your desired limit here
    const limitedProducts = ref([]);

    // Fetch data from your backend or API
    const fetchData = async () => {
      try {
        const response = await fetch('https://dummyjson.com/products');
        const data = await response.json();
        products.value = data.products; // Assuming your API returns an array of products
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    // Fetch data when the component is mounted
    onMounted(fetchData);

    return { products };
  }
};
</script>
