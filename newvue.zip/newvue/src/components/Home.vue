<template>
    <h1>Welcome From Home Page</h1>
  <div>
    <el-row>
    <el-col :span="12"><div class="grid-content ep-bg-purple" /><img src="https://images01.nicepagecdn.com/page/36/36/website-template-preview-3636619.webp" width="800px"></el-col>
    <el-col :span="12"><div class="grid-content ep-bg-purple-light" /><img src="https://mockup-assets.canva.com/templates/Etci8x7bP/003.jpg?resize-width=300&resize-format=auto" width="800px"></el-col>
  </el-row>
   
  </div>
  </template>
  
  <script>
export default{
  data(){
   
   
}
}
</script>
  