<script setup>

</script>

<template>
  <el-footer style="background:#efefef; height:200px;padding:10px;margin-top:30px;">
    <el-row>
    <el-col :span="8">
        <p>Technology is the application of conceptual knowledge for achieving practical goals, especially in a reproducible way. The word technology can also mean the products resulting from such efforts, including both tangible tools such as  </p>
        <span>(+66) 54 819 819</span><br>
        <span>(+66) 54 819 817</span>
    </el-col>
    <el-col :span="8" style="text-align:center;padding:5px;">
      <router-link to="/order">Order</router-link><br>
      <router-link to="/login">Login</router-link><br>
      
      </el-col>
    <el-col :span="8">
      <h4>Subscribe to our newsletter</h4>
      <p>Monthly digest of what's new and exciting from us.</p>

    </el-col>
    </el-row>
    <hr>
    <el-row :gutter="20">
    <el-col :offset="8">
            <p>© 2024 Company, Inc. All rights reserved.</p>
          </el-col>
           
          
        </el-row>
      </el-footer>
</template>

<style scoped>
h1 {
  font-weight: 500;
  font-size: 2.6rem;
  position: relative;
  top: -10px;
}

h3 {
  font-size: 1.2rem;
}

.greetings h1,
.greetings h3 {
  text-align: center;
}

@media (min-width: 1024px) {
  .greetings h1,
  .greetings h3 {
    text-align: left;
  }
}
</style>
