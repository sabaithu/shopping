<template>
  <div v-if="loading">Loading...</div>
    <div v-else>
    <el-row >
      <el-col :span="8">
        <!-- Render each product using Element UI Card component -->
        <el-card :body-style="{ padding: '0' }">
          <img :src="product.thumbnail" class="product-image" alt="product image">
          <div style="padding: 14px;">
            <h3>{{ product.title }}</h3>
            <p>{{ product.category }}</p>
            <p>{{ product.stock }}</p>
            <p>{{ product.description }}</p><el-rate v-model="rating" :max="5"></el-rate>
            <div class="bottom clearfix">
              <span class="price" style="color: red;font-size: 20px;">${{ product.price }}</span>
              <el-button type="primary"  style="float: right;margin: 20px;">Add to Cart</el-button>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
    
</template>

<script>
import { ref, onMounted } from 'vue';
import axios from 'axios';

export default {
  setup() {
    const product = ref(null);
    const loading = ref(true);
    
    onMounted(async () => {
      try {
        let id = 1;
        const response = await axios.get('https://dummyjson.com/products/' + id);
        product.value = response.data;
        loading.value = false;
      } catch (error) {
        console.error('Error fetching products:', error);
        loading.value = false;
      }
    });
    
 

    return { 
      product, 
      loading,
    
    };
  }
};
</script>
