<template>
  <div v-if="loading">Loading...</div>
    <div v-else>
    <el-row >
      <el-col :span="8" v-for="product in products" :key="product.id">
        <!-- Render each product using Element UI Card component -->
        <el-card :body-style="{ padding: '0' }">
          <router-link :to="{ name: 'product-single', params: { id: product.id }}"><img :src="product.thumbnail" class="product-image" alt="product image" style="padding:10px;"></router-link>
         
          <div style="padding: 14px;">
            <h3>{{ product.title }}</h3>
            <p>{{ product.category }}</p>
            <p>{{ product.stock }}</p>
            <p>{{ product.description }}</p><el-rate v-model="rating" :max="5"></el-rate>
            <div class="bottom clearfix">
              <span class="price" style="color: red;font-size: 20px;">${{ product.price }}</span>
              <el-button type="primary"     style="float: right;margin: 20px;">Add to Cart</el-button>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
  <div>
    
  </div>
</template>

<script>
import { ref, onMounted, reactive } from 'vue';
import axios from 'axios';

export default {
  setup() {
    let products = ref([]);
    const loading = ref(true);
    
    onMounted(async () => {
      try {
        const response = await axios.get('https://dummyjson.com/products');
        products.value = response.data.products;
        console.log(products)
        loading.value = false;
      } catch (error) {
        console.error('Error fetching products:', error);
        loading.value = false;
      }
    });
    return { 
      products, 
      loading,   
    
    };
  }
};
</script>
