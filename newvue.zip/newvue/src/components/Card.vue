<template>
  <div>
    <h2>Product Catalog</h2>
    <div class="product" v-for="product in products" :key="product.id">
      <h3>{{ product.name }}</h3>
      <p>Price: ${{ product.price }}</p>
      <button @click="addToCart(product)">Add to Cart</button>
    </div>

    <h2>Cart</h2>
    <div v-if="cart.length === 0">Your cart is empty</div>
    <div v-else>
      <div class="cart-item" v-for="item in cart" :key="item.id">
        <span>{{ item.name }}</span>
        <span>Price: ${{ item.price }}</span>
        <span>Quantity: {{ item.quantity }}</span>
        <button @click="removeFromCart(item)">Remove</button>
      </div>
      <button @click="checkout">Checkout</button>
    </div>
  </div>
</template>

<script>
import { ref } from 'vue';

export default {
  data() {
    return {
      products: [
        { id: 1, name: 'Product 1', price: 10 },
        { id: 2, name: 'Product 2', price: 20 },
        { id: 3, name: 'Product 3', price: 30 }
      ],
      cart: []
    };
  },
  methods: {
    addToCart(product) {
      const existingItem = this.cart.find(item => item.id === product.id);
      if (existingItem) {
        existingItem.quantity++;
      } else {
        this.cart.push({ ...product, quantity: 1 });
      }
    },
    removeFromCart(item) {
      const index = this.cart.findIndex(i => i.id === item.id);
      if (index !== -1) {
        if (this.cart[index].quantity > 1) {
          this.cart[index].quantity--;
        } else {
          this.cart.splice(index, 1);
        }
      }
    },
    checkout() {
      // Implement checkout logic here
      console.log('Checkout:', this.cart);
    }
  }
};
</script>

<style>
/* Add your custom styles here */
.product {
  margin-bottom: 20px;
}
.cart-item {
  margin-bottom: 10px;
}
</style>