// import './assets/main.css'

import { createApp } from 'vue'
import App from './App.vue'
const app = createApp(App)
import { createRouter, createWebHistory } from 'vue-router'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'

const routes =[
	{
        path :'/',
        name: 'home',
        component:import("./components/Home.vue")
    },
    {
        path :'/singup',
        name: 'singup',
        component:() => import("./components/Singup.vue")
    },
    {
        path :'/login',
        name: 'login',
        component:() => import("./components/Login.vue")
    },
    {
        path :'/logout',
        name: 'logout',
        component:() => import("./components/Home.vue")
    },
    {
        path :'/product',
        name: 'product',
        component:() => import("./components/Product.vue")
    },
    {
        path:'/product-single/:id',
        name:'product-single',
        component:()=> import("./components/ProductSingle.vue")
    },
    {
        path:'/product-list',
        name:'product-list',
        component:()=> import("./components/ProductList.vue")
    },
    
    {
        path :'/order',
        name: 'order',
        component:() => import("./components/Order.vue")
    },
    {
        path :'/card',
        name: 'card',
        component:() => import("./components/Card.vue")
    },
    {
        path:'/loader',
        name:'loader',
        component:()=> import("./components/Loader.vue")
    },
]
const router = createRouter({
    history:  createWebHistory(),
    routes
})

app.use(ElementPlus)
app.use(router)
app.mount('#app')
